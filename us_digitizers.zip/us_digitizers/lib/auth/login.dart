import 'dart:convert';
import 'dart:developer';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:usadigitizers/app/helpers/request-helper.dart';
import 'package:usadigitizers/auth/register.dart';
import 'package:usadigitizers/views/layouts/main-layout.dart';
import './widgets/auth-text-field.dart';
import '../basic/button.dart';
import '../app/helpers/constants.dart' as Constants;
import 'package:shared_preferences/shared_preferences.dart';
import '../app/models/User.dart';

class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final _formkey = GlobalKey<FormState>();
  final username = TextEditingController();
  final password = TextEditingController();
  bool _isLoading = false;
  Future<void> performLogin(BuildContext context) async {
    if (_formkey.currentState?.validate() ?? false) {
      setState(() {
        _isLoading = true;
      });
      log("sss");
      Dio dio = RequestHelper().getInstance();
      try {
        print("before getting url");
        Response res = await dio.post(
          Constants.BASEURL + '/login',
          data: jsonEncode({
            'username': username.text,
            'password': password.text,
          }),
        );
        print("${res.statusCode} + ${res.statusMessage}");
        log(res.data.toString());
        if (res.statusCode == 200) {
          log('working (after code 200)');
          SharedPreferences prefs = await SharedPreferences.getInstance();
          prefs.setString('user', json.encode(res.data));
          prefs.setString('accessToken', res.data["accessToken"]);
          debugPrint(json.encode(res.data));
          Constants.authCheck = true;
          Constants.authUser = User.fromJson(res.data);
          Constants.ACCESS_TOKEN = res.data["accessToken"];
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => MainLayout(index: 0)),
          );
        }
      } catch (error) {
        log(error.toString());
        if (error is DioException) {
          if (error.type == DioExceptionType.connectionTimeout) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text("Cannot connect to the server"),
            ));
          } else if (error.type == DioExceptionType.badResponse) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text("Invalid Credentials"),
            ));
          } else {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text("Cannot connect to the server"),
            ));
          }
        } else {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("An error occurred"),
          ));
        }
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void checkSavedUser(BuildContext context) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    // pref.remove('user');
    String? user = pref.getString('user');
    String? accessToken = pref.getString('accessToken');
    if (user != null) {
      try {
        Constants.authCheck = true;
        Constants.authUser = User.fromJson(json.decode(user));
        Constants.ACCESS_TOKEN = accessToken!;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => MainLayout(index: 0)),
        );
      } catch (e) {
        pref.remove("user");
        pref.remove("accessToken");
      }
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      checkSavedUser(context);
    });
    username.text = 'johnson';
    password.text = 'adwst17';
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarIconBrightness: Brightness.light,
        statusBarColor: Constants.THEME_BLUE,
      ),
      child: Scaffold(
        body: LoadingOverlay(
          isLoading: _isLoading,
          child: Container(
            color: Color(0xFFEEEEEE),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Stack(
                    children: [
                      Container(
                        height: 330,
                        child: SvgPicture.asset(
                          'assets/svg/auth-art-red.svg',
                          color: Constants.THEME_RED,
                          width: double.infinity,
                          fit: BoxFit.fill,
                        ),
                      ),
                      SvgPicture.asset(
                        'assets/svg/auth-art-blue.svg',
                        color: Constants.THEME_BLUE,
                      ),
                      Container(
                        margin: EdgeInsets.only(
                            left: 40,
                            right: 40,
                            bottom: 40,
                            top: 10 + MediaQuery.of(context).padding.top),
                        child: Text(
                          "Welcome to USA Digitizers",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 40,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  Container(
                    child: Form(
                      key: _formkey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          AuthTextField(
                              placeholder: "Username",
                              controller: username,
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Email is required';
                                }
                                return null;
                              },
                              icon: Icon(LineIcons.user)),
                          AuthTextField(
                            placeholder: "Password",
                            controller: password,
                            isPassword: true,
                            icon: Icon(LineIcons.lock),
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Password is required';
                              }
                              return null;
                            },
                          ),
                          CustomButton(
                            text: "Login",
                            action: () => performLogin(context),
                          )
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 20, bottom: 20),
                    child: Row(children: <Widget>[
                      Expanded(child: Divider()),
                      Text("OR"),
                      Expanded(child: Divider()),
                    ]),
                  ),
                  CustomButton(
                    text: "Sign Up",
                    action: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => Register()),
                      );
                    },
                    hasBorder: true,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
