import 'package:flutter/material.dart';

class AuthTextField extends StatelessWidget {
  final String placeholder;
  final TextEditingController controller;
  final Icon icon;
  final FormFieldValidator<String>? validator;
  final bool isPassword;
  AuthTextField(
      {required this.placeholder,
      required this.controller,
      required this.icon,
      this.validator,
      this.isPassword = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 30, right: 30, bottom: 10),
      child: Material(
        color: Colors.transparent,
        elevation: 0,
        borderRadius: BorderRadius.all(Radius.circular(40.0)),
        child: TextFormField(
          validator: this.validator,
          controller: this.controller,
          enableSuggestions: !isPassword,
          autocorrect: !isPassword,
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white,
            prefixIcon: this.icon,
            border: OutlineInputBorder(
              borderSide: BorderSide(
                width: 0.0,
                color: Colors.transparent,
              ),
              gapPadding: 20,
              borderRadius: BorderRadius.all(Radius.circular(40.0)),
            ),
            hintText: this.placeholder,
          ),
        ),
      ),
    );
  }
}
