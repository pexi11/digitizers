import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:usadigitizers/app/helpers/request-helper.dart';
import 'package:usadigitizers/app/models/User.dart';
import 'package:usadigitizers/auth/login.dart';
import 'package:usadigitizers/auth/widgets/auth-text-field.dart';
import 'package:usadigitizers/views/layouts/main-layout.dart';
import '../app/helpers/constants.dart' as Constants;
import 'package:usadigitizers/basic/button.dart';

class Register extends StatefulWidget {
  @override
  _RegisterState createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  bool _isLoading = false;
  final _formkey = GlobalKey<FormState>();
  final name = TextEditingController();
  final company = TextEditingController();
  final phone = TextEditingController();
  final email = TextEditingController();
  final username = TextEditingController();
  final password = TextEditingController();

  void performRegister(context) async {
    if (this._formkey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });
      Dio dio = RequestHelper().getInstance();
      Response res = await dio
          .post(
        Constants.BASEURL + '/register',
        data: jsonEncode({
          'name': this.name.text,
          'company': this.company.text,
          'phone': this.phone.text,
          'email': this.email.text,
          'username': this.username.text,
          'password': this.password.text
        }),
      )
          .catchError((error) {
        if (error.type == DioExceptionType.connectionTimeout) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("Cannot connect to the server"),
          ));
        }
        if (error.type == DioExceptionType.badResponse) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("Invalid Credentials"),
          ));
          setState(() {
            _isLoading = false;
          });
        }
        return Response(
            requestOptions: error.requestOptions); // Ensure a value is returned
      });
      // debugPrint(res.body);
      if (res != null) {
        if (res.statusCode == 200) {
          SharedPreferences prefs = await SharedPreferences.getInstance();
          prefs.setString('user', json.encode(res.data));
          prefs.setString('accessToken', res.data["access_token"]);
          debugPrint(json.encode(res.data));
          Constants.authCheck = true;
          Constants.authUser = User.fromJson(res.data);
          Constants.ACCESS_TOKEN = res.data["access_token"];
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => MainLayout(index: 0)),
          );
        }
      }
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarIconBrightness: Brightness.light,
        statusBarColor: Constants.THEME_BLUE,
      ),
      child: Scaffold(
        body: LoadingOverlay(
          isLoading: _isLoading,
          child: Builder(builder: (context) {
            return SafeArea(
              child: Container(
                color: Color(0xFFEEEEEEE),
                child: ListView(
                  children: [
                    Container(
                      color: Constants.THEME_RED,
                      margin: EdgeInsets.only(bottom: 20),
                      child: Padding(
                        padding: const EdgeInsets.all(40),
                        child: Text(
                          "Free Registration",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 30,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                    Column(
                      children: [
                        Container(
                          color: Colors.transparent,
                          child: Form(
                            key: _formkey,
                            child: Column(
                              children: <Widget>[
                                AuthTextField(
                                  placeholder: "Contact Name",
                                  controller: this.name,
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      return 'Contact Name is required';
                                    }
                                    return null;
                                  },
                                  icon: Icon(LineIcons.user),
                                ),
                                AuthTextField(
                                  placeholder: "Company Name",
                                  controller: this.company,
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      return 'Company name is required';
                                    }
                                    return null;
                                  },
                                  icon: Icon(LineIcons.user),
                                ),
                                AuthTextField(
                                  placeholder: "Phone Number",
                                  controller: this.phone,
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      return 'Phone Number is required';
                                    }
                                    return null;
                                  },
                                  icon: Icon(LineIcons.user),
                                ),
                                AuthTextField(
                                  placeholder: "Email Address",
                                  controller: this.email,
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      return 'Email Address is required';
                                    }
                                    return null;
                                  },
                                  icon: Icon(LineIcons.user),
                                ),
                                AuthTextField(
                                  placeholder: "User ID",
                                  controller: this.username,
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      return 'User ID is required';
                                    }
                                    return null;
                                  },
                                  icon: Icon(LineIcons.user),
                                ),
                                AuthTextField(
                                  placeholder: "Password",
                                  controller: this.password,
                                  icon: Icon(LineIcons.lock),
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      return 'Password is required';
                                    }
                                    return null;
                                  },
                                ),
                                CustomButton(
                                  text: "Register",
                                  action: () => {this.performRegister(context)},
                                )
                              ],
                              mainAxisAlignment: MainAxisAlignment.center,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(top: 20, bottom: 20),
                          child: Row(children: <Widget>[
                            Expanded(child: Divider()),
                            Text("OR"),
                            Expanded(child: Divider()),
                          ]),
                        ),
                        CustomButton(
                          text: "Login",
                          action: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => Login()),
                            );
                          },
                          hasBorder: true,
                        ),
                      ],
                    )
                  ],
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}
