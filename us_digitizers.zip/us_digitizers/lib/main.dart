import 'package:flutter/material.dart';
import 'package:usadigitizers/app/helpers/constants.dart';
import 'auth/login.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Material(
      child: Login(),
    ),
    theme: ThemeData(
        textTheme: GoogleFonts.poppinsTextTheme(),
        primaryColor: THEME_BLUE,
        hintColor: THEME_RED),
  ));
}
