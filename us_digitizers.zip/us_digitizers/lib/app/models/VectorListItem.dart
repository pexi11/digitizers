class Vector {
  dynamic vectorId;
  dynamic vectorNo;
  dynamic vectorName;
  dynamic vectorFormat;
  dynamic vectorColors;
  dynamic vectorUrgent;
  dynamic vectorAdditionalInfo;
  dynamic vectorInstructions;
  dynamic vectorType;
  dynamic vectorPrice;
  dynamic vectorReleaseDate;
  dynamic vectorStatus;
  dynamic vectorPaymentStatus;
  dynamic vectorHistory;
  dynamic vectorEdited;
  dynamic vectorInInvoice;
  dynamic vectorDesignerId;
  dynamic vectorUserId;
  dynamic vectorCreatedBy;
  dynamic createdAt;
  dynamic updatedAt;

  Vector(
      {this.vectorId,
      this.vectorNo,
      this.vectorName,
      this.vectorFormat,
      this.vectorColors,
      this.vectorUrgent,
      this.vectorAdditionalInfo,
      this.vectorInstructions,
      this.vectorType,
      this.vectorPrice,
      this.vectorReleaseDate,
      this.vectorStatus,
      this.vectorPaymentStatus,
      this.vectorHistory,
      this.vectorEdited,
      this.vectorInInvoice,
      this.vectorDesignerId,
      this.vectorUserId,
      this.vectorCreatedBy,
      this.createdAt,
      this.updatedAt});

  Vector.fromJson(Map<String, dynamic> json) {
    vectorId = json['vector_id'];
    vectorNo = json['vector_no'];
    vectorName = json['vector_name'];
    vectorFormat = json['vector_format'];
    vectorColors = json['vector_colors'];
    vectorUrgent = json['vector_urgent'];
    vectorAdditionalInfo = json['vector_additional_info'];
    vectorInstructions = json['vector_instructions'];
    vectorType = json['vector_type'];
    vectorPrice = json['vector_price'];
    vectorReleaseDate = json['vector_release_date'];
    vectorStatus = json['vector_status'];
    vectorPaymentStatus = json['vector_payment_status'];
    vectorHistory = json['vector_history'];
    vectorEdited = json['vector_edited'];
    vectorInInvoice = json['vector_in_invoice'];
    vectorDesignerId = json['vector_designer_id'];
    vectorUserId = json['vector_user_id'];
    vectorCreatedBy = json['vector_created_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['vector_id'] = this.vectorId;
    data['vector_no'] = this.vectorNo;
    data['vector_name'] = this.vectorName;
    data['vector_format'] = this.vectorFormat;
    data['vector_colors'] = this.vectorColors;
    data['vector_urgent'] = this.vectorUrgent;
    data['vector_additional_info'] = this.vectorAdditionalInfo;
    data['vector_instructions'] = this.vectorInstructions;
    data['vector_type'] = this.vectorType;
    data['vector_price'] = this.vectorPrice;
    data['vector_release_date'] = this.vectorReleaseDate;
    data['vector_status'] = this.vectorStatus;
    data['vector_payment_status'] = this.vectorPaymentStatus;
    data['vector_history'] = this.vectorHistory;
    data['vector_edited'] = this.vectorEdited;
    data['vector_in_invoice'] = this.vectorInInvoice;
    data['vector_designer_id'] = this.vectorDesignerId;
    data['vector_user_id'] = this.vectorUserId;
    data['vector_created_by'] = this.vectorCreatedBy;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
