class Quote {
  dynamic quoteId;
  dynamic quoteNo;
  dynamic quoteName;
  dynamic quoteHeight;
  dynamic quoteWidth;
  dynamic quoteFormat;
  dynamic quoteFabric;
  dynamic quotePlacement;
  dynamic quoteColors;
  dynamic quoteUrgent;
  dynamic quoteAdditionalInfo;
  dynamic quoteInstructions;
  dynamic quoteType;
  dynamic quotePrice;
  dynamic quoteReleaseDate;
  dynamic quoteStatus;
  dynamic quoteDeleteStatus;
  dynamic quoteConverted;
  dynamic quoteHistory;
  dynamic quoteEdited;
  dynamic quoteDesignerId;
  dynamic quoteUserId;
  dynamic quoteCreatedBy;
  dynamic createdAt;
  dynamic updatedAt;

  Quote(
      {this.quoteId,
      this.quoteNo,
      this.quoteName,
      this.quoteHeight,
      this.quoteWidth,
      this.quoteFormat,
      this.quoteFabric,
      this.quotePlacement,
      this.quoteColors,
      this.quoteUrgent,
      this.quoteAdditionalInfo,
      this.quoteInstructions,
      this.quoteType,
      this.quotePrice,
      this.quoteReleaseDate,
      this.quoteStatus,
      this.quoteDeleteStatus,
      this.quoteConverted,
      this.quoteHistory,
      this.quoteEdited,
      this.quoteDesignerId,
      this.quoteUserId,
      this.quoteCreatedBy,
      this.createdAt,
      this.updatedAt});

  Quote.fromJson(Map<String, dynamic> json) {
    quoteId = json['quote_id'];
    quoteNo = json['quote_no'];
    quoteName = json['quote_name'];
    quoteHeight = json['quote_height'];
    quoteWidth = json['quote_width'];
    quoteFormat = json['quote_format'];
    quoteFabric = json['quote_fabric'];
    quotePlacement = json['quote_placement'];
    quoteColors = json['quote_colors'];
    quoteUrgent = json['quote_urgent'];
    quoteAdditionalInfo = json['quote_additional_info'];
    quoteInstructions = json['quote_instructions'];
    quoteType = json['quote_type'];
    quotePrice = json['quote_price'];
    quoteReleaseDate = json['quote_release_date'];
    quoteStatus = json['quote_status'];
    quoteDeleteStatus = json['quote_delete_status'];
    quoteConverted = json['quote_converted'];
    quoteHistory = json['quote_history'];
    quoteEdited = json['quote_edited'];
    quoteDesignerId = json['quote_designer_id'];
    quoteUserId = json['quote_user_id'];
    quoteCreatedBy = json['quote_created_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['quote_id'] = this.quoteId;
    data['quote_no'] = this.quoteNo;
    data['quote_name'] = this.quoteName;
    data['quote_height'] = this.quoteHeight;
    data['quote_width'] = this.quoteWidth;
    data['quote_format'] = this.quoteFormat;
    data['quote_fabric'] = this.quoteFabric;
    data['quote_placement'] = this.quotePlacement;
    data['quote_colors'] = this.quoteColors;
    data['quote_urgent'] = this.quoteUrgent;
    data['quote_additional_info'] = this.quoteAdditionalInfo;
    data['quote_instructions'] = this.quoteInstructions;
    data['quote_type'] = this.quoteType;
    data['quote_price'] = this.quotePrice;
    data['quote_release_date'] = this.quoteReleaseDate;
    data['quote_status'] = this.quoteStatus;
    data['quote_delete_status'] = this.quoteDeleteStatus;
    data['quote_converted'] = this.quoteConverted;
    data['quote_history'] = this.quoteHistory;
    data['quote_edited'] = this.quoteEdited;
    data['quote_designer_id'] = this.quoteDesignerId;
    data['quote_user_id'] = this.quoteUserId;
    data['quote_created_by'] = this.quoteCreatedBy;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
