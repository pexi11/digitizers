class Customer {
  dynamic customerId;
  dynamic customerCompany;
  dynamic customerCompanyType;
  dynamic customerPhone;
  dynamic customerCell;
  dynamic customerFax;
  dynamic customerEmail2;
  dynamic customerEmail3;
  dynamic customerEmail4;
  dynamic customerEmail5;
  dynamic customerAddress;
  dynamic customerCity;
  dynamic customerState;
  dynamic customerZipcode;
  dynamic customerCountry;
  dynamic customerReference;
  dynamic customerReceivables;
  dynamic customerUserId;

  Customer(
      {this.customerId,
      this.customerCompany,
      this.customerCompanyType,
      this.customerPhone,
      this.customerCell,
      this.customerFax,
      this.customerEmail2,
      this.customerEmail3,
      this.customerEmail4,
      this.customerEmail5,
      this.customerAddress,
      this.customerCity,
      this.customerState,
      this.customerZipcode,
      this.customerCountry,
      this.customerReference,
      this.customerReceivables,
      this.customerUserId});

  Customer.fromJson(Map<String, dynamic> json) {
    customerId = json['customer_id'];
    customerCompany = json['customer_company'];
    customerCompanyType = json['customer_company_type'];
    customerPhone = json['customer_phone'];
    customerCell = json['customer_cell'];
    customerFax = json['customer_fax'];
    customerEmail2 = json['customer_email2'];
    customerEmail3 = json['customer_email3'];
    customerEmail4 = json['customer_email4'];
    customerEmail5 = json['customer_email5'];
    customerAddress = json['customer_address'];
    customerCity = json['customer_city'];
    customerState = json['customer_state'];
    customerZipcode = json['customer_zipcode'];
    customerCountry = json['customer_country'];
    customerReference = json['customer_reference'];
    customerReceivables = json['customer_receivables'];
    customerUserId = json['customer_user_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['customer_id'] = this.customerId;
    data['customer_company'] = this.customerCompany;
    data['customer_company_type'] = this.customerCompanyType;
    data['customer_phone'] = this.customerPhone;
    data['customer_cell'] = this.customerCell;
    data['customer_fax'] = this.customerFax;
    data['customer_email2'] = this.customerEmail2;
    data['customer_email3'] = this.customerEmail3;
    data['customer_email4'] = this.customerEmail4;
    data['customer_email5'] = this.customerEmail5;
    data['customer_address'] = this.customerAddress;
    data['customer_city'] = this.customerCity;
    data['customer_state'] = this.customerState;
    data['customer_zipcode'] = this.customerZipcode;
    data['customer_country'] = this.customerCountry;
    data['customer_reference'] = this.customerReference;
    data['customer_receivables'] = this.customerReceivables;
    data['customer_user_id'] = this.customerUserId;
    return data;
  }
}
