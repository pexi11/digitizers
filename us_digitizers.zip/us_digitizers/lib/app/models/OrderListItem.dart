class Order {
  dynamic orderId;
  dynamic orderNo;
  dynamic orderName;
  dynamic orderHeight;
  dynamic orderWidth;
  dynamic orderFormat;
  dynamic orderFabric;
  dynamic orderPlacement;
  dynamic orderColors;
  dynamic orderUrgent;
  dynamic orderAdditionalInfo;
  dynamic orderInstructions;
  dynamic orderType;
  dynamic orderPrice;
  dynamic orderReleaseDate;
  dynamic orderStatus;
  dynamic orderPaymentStatus;
  dynamic orderHistory;
  dynamic orderEdited;
  dynamic orderInInvoice;
  dynamic orderDesignerId;
  dynamic orderUserId;
  dynamic orderCreatedBy;
  dynamic createdAt;
  dynamic updatedAt;

  Order(
      {this.orderId,
      this.orderNo,
      this.orderName,
      this.orderHeight,
      this.orderWidth,
      this.orderFormat,
      this.orderFabric,
      this.orderPlacement,
      this.orderColors,
      this.orderUrgent,
      this.orderAdditionalInfo,
      this.orderInstructions,
      this.orderType,
      this.orderPrice,
      this.orderReleaseDate,
      this.orderStatus,
      this.orderPaymentStatus,
      this.orderHistory,
      this.orderEdited,
      this.orderInInvoice,
      this.orderDesignerId,
      this.orderUserId,
      this.orderCreatedBy,
      this.createdAt,
      this.updatedAt});

  Order.fromJson(Map<String, dynamic> json) {
    orderId = json['order_id'];
    orderNo = json['order_no'];
    orderName = json['order_name'];
    orderHeight = json['order_height'];
    orderWidth = json['order_width'];
    orderFormat = json['order_format'];
    orderFabric = json['order_fabric'];
    orderPlacement = json['order_placement'];
    orderColors = json['order_colors'];
    orderUrgent = json['order_urgent'];
    orderAdditionalInfo = json['order_additional_info'];
    orderInstructions = json['order_instructions'];
    orderType = json['order_type'];
    orderPrice = json['order_price'];
    orderReleaseDate = json['order_release_date'];
    orderStatus = json['order_status'];
    orderPaymentStatus = json['order_payment_status'];
    orderHistory = json['order_history'];
    orderEdited = json['order_edited'];
    orderInInvoice = json['order_in_invoice'];
    orderDesignerId = json['order_designer_id'];
    orderUserId = json['order_user_id'];
    orderCreatedBy = json['order_created_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['order_id'] = this.orderId;
    data['order_no'] = this.orderNo;
    data['order_name'] = this.orderName;
    data['order_height'] = this.orderHeight;
    data['order_width'] = this.orderWidth;
    data['order_format'] = this.orderFormat;
    data['order_fabric'] = this.orderFabric;
    data['order_placement'] = this.orderPlacement;
    data['order_colors'] = this.orderColors;
    data['order_urgent'] = this.orderUrgent;
    data['order_additional_info'] = this.orderAdditionalInfo;
    data['order_instructions'] = this.orderInstructions;
    data['order_type'] = this.orderType;
    data['order_price'] = this.orderPrice;
    data['order_release_date'] = this.orderReleaseDate;
    data['order_status'] = this.orderStatus;
    data['order_payment_status'] = this.orderPaymentStatus;
    data['order_history'] = this.orderHistory;
    data['order_edited'] = this.orderEdited;
    data['order_in_invoice'] = this.orderInInvoice;
    data['order_designer_id'] = this.orderDesignerId;
    data['order_user_id'] = this.orderUserId;
    data['order_created_by'] = this.orderCreatedBy;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
