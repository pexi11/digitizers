class BillingInfoModel {
  dynamic billingId;
  dynamic billingName;
  dynamic billingType;
  dynamic billingCardNumber;
  dynamic billingExpMonth;
  dynamic billingExpYear;
  dynamic billingVcc;
  dynamic billingAddress;
  dynamic billingCity;
  dynamic billingState;
  dynamic billingZipcode;
  dynamic billingCountry;
  dynamic billingUserId;
  dynamic createdAt;
  dynamic updatedAt;

  BillingInfoModel(
      {this.billingId,
      this.billingName,
      this.billingType,
      this.billingCardNumber,
      this.billingExpMonth,
      this.billingExpYear,
      this.billingVcc,
      this.billingAddress,
      this.billingCity,
      this.billingState,
      this.billingZipcode,
      this.billingCountry,
      this.billingUserId,
      this.createdAt,
      this.updatedAt});

  BillingInfoModel.fromJson(Map<String, dynamic> json) {
    billingId = json['billing_id'];
    billingName = json['billing_name'];
    billingType = json['billing_type'];
    billingCardNumber = json['billing_card_number'];
    billingExpMonth = json['billing_exp_month'];
    billingExpYear = json['billing_exp_year'];
    billingVcc = json['billing_vcc'];
    billingAddress = json['billing_address'];
    billingCity = json['billing_city'];
    billingState = json['billing_state'];
    billingZipcode = json['billing_zipcode'];
    billingCountry = json['billing_country'];
    billingUserId = json['billing_user_id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['billing_id'] = this.billingId;
    data['billing_name'] = this.billingName;
    data['billing_type'] = this.billingType;
    data['billing_card_number'] = this.billingCardNumber;
    data['billing_exp_month'] = this.billingExpMonth;
    data['billing_exp_year'] = this.billingExpYear;
    data['billing_vcc'] = this.billingVcc;
    data['billing_address'] = this.billingAddress;
    data['billing_city'] = this.billingCity;
    data['billing_state'] = this.billingState;
    data['billing_zipcode'] = this.billingZipcode;
    data['billing_country'] = this.billingCountry;
    data['billing_user_id'] = this.billingUserId;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
