class User {
  dynamic id;
  dynamic username;
  dynamic name;
  dynamic email;
  dynamic password;
  dynamic passwordShow;
  dynamic role;
  dynamic status;
  dynamic rememberToken;
  dynamic createdAt;
  dynamic updatedAt;
  dynamic accessToken;

  User(
      {this.id,
      this.username,
      this.name,
      this.email,
      this.password,
      this.passwordShow,
      this.role,
      this.status,
      this.rememberToken,
      this.createdAt,
      this.updatedAt,
      this.accessToken});

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    username = json['username'];
    name = json['name'];
    email = json['email'];
    password = json['password'];
    passwordShow = json['password_show'];
    role = json['role'];
    status = json['status'];
    rememberToken = json['remember_token'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    accessToken = json['access_token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['username'] = this.username;
    data['name'] = this.name;
    data['email'] = this.email;
    data['password'] = this.password;
    data['password_show'] = this.passwordShow;
    data['role'] = this.role;
    data['status'] = this.status;
    data['remember_token'] = this.rememberToken;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['access_token'] = this.accessToken;
    return data;
  }
}
