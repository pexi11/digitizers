import 'package:dio/dio.dart';
import 'package:usadigitizers/app/helpers/constants.dart' as Constants;

class RequestHelper {
  Dio dio = new Dio();
  RequestHelper() {
    this.dio = new Dio(); // with default Options

// Set default configs
    this.dio.options.baseUrl = Constants.BASEURL;
    dio.options.headers["Authorization"] = "Bearer " + Constants.ACCESS_TOKEN;
    dio.options.headers["Accepts"] = "application/json";
    dio.options.connectTimeout = Duration(milliseconds: 50000);
  }

  Dio getInstance() {
    return this.dio;
  }
}
