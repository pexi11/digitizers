library constants;

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:usadigitizers/app/models/OrderListItem.dart';
import 'package:usadigitizers/app/models/QuoteListItem.dart';
import 'package:usadigitizers/app/models/User.dart';
import 'package:usadigitizers/app/models/VectorListItem.dart';

const String BASEURL = "https://usadigitizers.com/api";
// ignore: non_constant_identifier_names
String ACCESS_TOKEN = "";
bool authCheck = false;
User authUser = new User();
// ignore: non_constant_identifier_names
Color THEME_BLUE = Color(0xFF25215E);
// ignore: non_constant_identifier_names
Color THEME_RED = Color(0xFFC74B57);

// ignore: non_constant_identifier_names
List<Order> ORDER_ITEMS = [];
// ignore: non_constant_identifier_names
List<Quote> QUOTE_ITEMS = [];
// ignore: non_constant_identifier_names
List<Vector> VECTOR_ITEMS = [];

int orderPageNumber = 0;
int orderTotalRecords = 0;

int quotePageNumber = 0;
int quoteTotalRecords = 0;

int vectorPageNumber = 0;
int vectorTotalRecords = 0;

// ignore: non_constant_identifier_names
bool HOME_LOADED = false;
// ignore: non_constant_identifier_names
List<Order> HOME_ORDER_ITEMS = [];
// ignore: non_constant_identifier_names
List<Quote> HOME_QUOTE_ITEMS = [];
// ignore: non_constant_identifier_names
List<Vector> HOME_VECTOR_ITEMS = [];

String dateFormatHelper(datetime) {
  if (datetime == null) return "";
  try {
    return DateFormat('MM-dd-yyyy kk:mm').format(DateTime.parse(datetime));
  } catch (e) {
    return "";
  }
}
