import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:usadigitizers/app/helpers/constants.dart';
import 'package:usadigitizers/views/home.dart';
import 'package:usadigitizers/views/widgets/contact.dart';
import 'package:usadigitizers/views/widgets/profile.dart';
import 'package:usadigitizers/views/widgets/records-tabs.dart';
import '../widgets/order-menu.dart';
import 'package:line_icons/line_icons.dart';

class MainLayout extends StatefulWidget {
   int? index = 0;
  MainLayout({ this.index});
  @override
  _MainLayoutState createState() => _MainLayoutState();
}

class _MainLayoutState extends State<MainLayout> {
  int? _index;
  List<Widget>? widgets;

  void debugMessage() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    debugPrint(pref.getString('accessToken'));
  }

  void switchPage(int value) {
    setState(() {
      _index = value;
    });
  }

  @override
  void initState() {
    super.initState();
    _index = widget.index;
    this.widgets = [
      Home(),
      RecordsTabs(),
      OrderMenu(
        changeTab: (int index) => switchPage(index),
      ),
      ContactForm(),
      Profile()
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: this.widgets?[_index ?? 0],
        ),
      ),
      bottomNavigationBar: CurvedNavigationBar(
          index: _index ?? 0,
          height: 75,
          color: THEME_RED,
          backgroundColor: Colors.grey.shade400,
          onTap: (index) {
            setState(() {
              _index = index;
            });
          },
          items: [
            Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Icon(
                  LineIcons.home,
                  color: Colors.white,
                ),
                if (_index != 0)
                  Text(
                    "Home",
                    style: TextStyle(color: Colors.white),
                  ),
              ],
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Icon(
                  LineIcons.folderOpen,
                  color: Colors.white,
                ),
                if (_index != 1)
                  Text(
                    "Records",
                    style: TextStyle(color: Colors.white),
                  ),
              ],
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Icon(
                  LineIcons.plusSquare,
                  color: Colors.white,
                ),
                if (_index != 2)
                  Text(
                    "Place Order",
                    style: TextStyle(color: Colors.white),
                  ),
              ],
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Icon(
                  LineIcons.envelope,
                  color: Colors.white,
                ),
                if (_index != 3)
                  Text(
                    "Contact",
                    style: TextStyle(color: Colors.white),
                  ),
              ],
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Icon(
                  LineIcons.user,
                  color: Colors.white,
                ),
                if (_index != 4)
                  Text(
                    "Profile",
                    style: TextStyle(color: Colors.white),
                  ),
              ],
            )
          ]),
    );
  }
}
