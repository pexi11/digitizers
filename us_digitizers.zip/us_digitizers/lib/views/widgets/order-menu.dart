import 'package:flutter/material.dart';
import 'package:usadigitizers/app/models/OrderListItem.dart';
import 'package:usadigitizers/views/widgets/forms/digitizing-order.dart';
import 'package:usadigitizers/views/widgets/forms/quote-order.dart';
import 'package:usadigitizers/views/widgets/forms/vector-order.dart';

class OrderMenu extends StatelessWidget {
  final Function changeTab;
  OrderMenu({required this.changeTab});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            MenuItem(
              changeTab: changeTab,
              text: 'PLACE ORDER',
              image: AssetImage('assets/images/digitizing.jpg'),
              action:
                  DigitizingOrderForm(), // Assuming Order() is a valid constructor
            ),
            MenuItem(
              changeTab: changeTab,
              text: 'PLACE QUOTE',
              image: AssetImage('assets/images/quote.jpg'),
              action: DigitizingQuoteForm(changeTab: this.changeTab),
            ),
            MenuItem(
              changeTab: changeTab,
              text: 'PLACE VECTOR',
              image: AssetImage('assets/images/vector.png'),
              action: DigitizingVectorForm(changeTab: this.changeTab),
            ),
          ],
        ),
      ),
    );
  }
}

class MenuItem extends StatelessWidget {
  const MenuItem(
      {Key? key,
      required this.changeTab,
      required this.image,
      required this.action,
      required this.text})
      : super(key: key);

  final Function changeTab;
  final ImageProvider image;
  final String text;
  final Widget action;
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: InkWell(
          onTap: () => {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => this.action),
            ),
          },
          child: SizedBox(
              width: double.infinity,
              child: Stack(
                children: [
                  Container(
                    width: double.infinity,
                    child: Image(
                      fit: BoxFit.fill,
                      image: this.image,
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    height: double.infinity,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: const Color.fromRGBO(0, 0, 0, 0.8),
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    height: double.infinity,
                    width: double.infinity,
                    child: Container(
                      padding: EdgeInsets.all(15),
                      decoration: BoxDecoration(
                          border: Border.all(width: 4, color: Colors.white)),
                      child: Text(
                        this.text,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 28,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  )
                ],
              )),
        ),
      ),
    );
  }
}
