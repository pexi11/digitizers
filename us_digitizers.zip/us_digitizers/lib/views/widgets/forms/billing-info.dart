import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:usadigitizers/app/helpers/constants.dart';
import 'package:usadigitizers/app/helpers/request-helper.dart';
import 'package:usadigitizers/app/models/BillingInfo.dart';
import 'package:usadigitizers/basic/button.dart';
import 'package:usadigitizers/basic/dropdown.dart';
import 'package:usadigitizers/basic/text-field.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:usadigitizers/views/home.dart';

class BillingInfo extends StatefulWidget {
  @override
  _BillingInfoState createState() => _BillingInfoState();
}

class _BillingInfoState extends State<BillingInfo> {
  final _formKey = GlobalKey<FormState>();
  final name = new TextEditingController();
  String? type;
  final number = new TextEditingController();
  String? month;
  String? year;
  final vcc = new TextEditingController();
  final address = new TextEditingController();
  final state = new TextEditingController();
  final city = new TextEditingController();
  final zipcode = new TextEditingController();
  int? country;
  String? countryString;

  var maskFormatter = new MaskTextInputFormatter(
      mask: '(###) ###-####', filter: {"#": RegExp(r'[0-9]')});
  List<DropdownMenuItem<String>> countryList = [];
  bool _isLoading = false;

  Future _loadData() async {
    setState(() {
      _isLoading = true;
    });
    Dio dio = RequestHelper().getInstance();
    Response response = await dio.get('/billing/get');
    if (response.statusCode == 200) {
      BillingInfoModel billing = BillingInfoModel.fromJson(response.data);
      setState(() {
        name.text = billing.billingName;
        type = billing.billingType;
        number.text = billing.billingCardNumber;
        month = billing.billingExpMonth;
        year = billing.billingExpYear;
        vcc.text = billing.billingVcc;
        address.text = billing.billingAddress;
        state.text = billing.billingState;
        city.text = billing.billingCity;
        zipcode.text = billing.billingZipcode;
        countryString = billing.billingCountry.toString();
        _isLoading = false;
      });
    } else {}
  }

  void updateBilling(BuildContext context) async {
    if (this._formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });
      FormData formData = new FormData.fromMap({
        "billing_name": this.name.text,
        "billing_type": this.type,
        "billing_card_number": this.number.text,
        "billing_exp_month": this.month,
        "billing_exp_year": this.year,
        "billing_vcc": this.vcc.text,
        "billing_address": this.address.text,
        "billing_city": this.city.text,
        "billing_state": this.state.text,
        "billing_zipcode": this.zipcode.text,
        "billing_country":
            this.countryString != null ? int.parse(this.countryString!) : null,
      });

      Dio dio = new RequestHelper().getInstance();
      Response response = Response(requestOptions: RequestOptions(path: ''));
      try {
        response = await dio.post(
          '/billing/update',
          data: formData,
        );
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionTimeout) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("Cannot connect to the server"),
          ));
        }
        if (e.type == DioExceptionType.badResponse) {
          if (e.response?.statusCode == 422) {
            ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(e.response?.data['errors'].first)));
          } else {
            ScaffoldMessenger.of(context)
                .showSnackBar(SnackBar(content: Text("Something went wrong!")));
          }
        }
        print("in catch");
      }
      setState(() {
        _isLoading = false;
      });
      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Billing updated successfully!")));
      }
    }
  }

  Future _loadCountries() async {
    Dio dio = RequestHelper().getInstance();
    Response response = await dio.get('/countries');
    if (response.statusCode == 200) {
      Map<String, dynamic>.from(response.data).forEach((key, value) {
        setState(() {
          countryList.add(
            DropdownMenuItem(
              child: Text(value),
              value: key,
            ),
          );
        });
      });
    }
  }

  List<DropdownMenuItem<String>> cardTypes() {
    return [
      "Visa",
      "Mastercard",
      "Discovery",
      "American Express",
    ]
        .map(
          (e) => DropdownMenuItem(
            child: Text(e),
            value: e,
          ),
        )
        .toList();
  }

  List<DropdownMenuItem<String>> monthList() {
    return [
      "01",
      "02",
      "03",
      "04",
      "05",
      "06",
      "07",
      "08",
      "09",
      "10",
      "11",
      "12"
    ]
        .map(
          (e) => DropdownMenuItem(
            child: Text(e),
            value: e,
          ),
        )
        .toList();
  }

  List<DropdownMenuItem<String>> yearList() {
    int cyear = new DateTime.now().year;
    List<String> years = [];

    for (var i = 0; i < 10; i++) {
      years.add((cyear + i).toString());
    }
    return years
        .map(
          (e) => DropdownMenuItem(
            child: Text(e),
            value: e,
          ),
        )
        .toList();
  }

  void setState(fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  void countryChange(value) {
    setState(() {
      this.countryString = value;
    });
  }

  void updateMonth(value) {
    setState(() {
      this.month = value;
    });
  }

  void updateYear(value) {
    setState(() {
      this.year = value;
    });
  }

  void updateCardType(value) {
    setState(() {
      this.type = value;
    });
  }

  @override
  void initState() {
    super.initState();
    _loadData();
    _loadCountries();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LoadingOverlay(
        isLoading: _isLoading,
        child: Builder(builder: (context) {
          return SafeArea(
            child: ListView(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 20, top: 20),
                  child: Align(
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Icon(
                        Icons.arrow_back,
                        size: 40,
                        color: THEME_BLUE,
                      ),
                    ),
                    alignment: Alignment.topLeft,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 20,
                  ),
                  child: HeadingTextBig("Billing Info"),
                ),
                Padding(
                  padding:
                      const EdgeInsets.only(bottom: 50, left: 20, right: 20),
                  child: Card(
                    elevation: 20,
                    margin: EdgeInsets.only(top: 40),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 50, top: 40),
                      child: Form(
                        child: Form(
                          key: _formKey,
                          child: Column(
                            children: [
                              CustomTextField(
                                placeholder: 'Cardholder\'s name (required)',
                                controller: this.name,
                                maxLines: 1,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Cardholder\'s name is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomDropdown(
                                items: this.cardTypes(),
                                placeholder: "Select Card",
                                onUpdate: this.updateCardType,
                                value: this.type,
                              ),
                              CustomTextField(
                                placeholder: 'Credit Card Number (required)',
                                controller: this.number,
                                maxLines: 1,
                                validator: (value) {
                                  if (value?.isEmpty ?? true) {
                                    return 'Credit Card Number is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomDropdown(
                                items: this.monthList(),
                                placeholder: "Expiry Month",
                                onUpdate: this.updateMonth,
                                value: this.month,
                              ),
                              CustomDropdown(
                                items: this.yearList(),
                                placeholder: "Expiry Year",
                                onUpdate: this.updateYear,
                                value: this.year,
                              ),
                              CustomTextField(
                                placeholder: 'Verification Number (required)',
                                controller: this.vcc,
                                maxLines: 1,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Verification Number is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomTextField(
                                placeholder: 'Address',
                                controller: this.address,
                                maxLines: 3,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Address is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomTextField(
                                placeholder: 'City',
                                controller: this.city,
                                maxLines: 1,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'City is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomTextField(
                                placeholder: 'State',
                                controller: this.state,
                                maxLines: 1,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'State is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomTextField(
                                placeholder: 'Zipcode',
                                controller: this.zipcode,
                                maxLines: 1,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Zipcode is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomDropdown(
                                items: this.countryList,
                                placeholder: "Country",
                                onUpdate: this.countryChange,
                                value: this.countryString,
                              ),
                              CustomButton(
                                action: () => {this.updateBilling(context)},
                                text: "Update Billing Info",
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}
