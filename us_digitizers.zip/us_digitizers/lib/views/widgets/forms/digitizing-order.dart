import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:usadigitizers/app/helpers/constants.dart';
import 'package:usadigitizers/app/helpers/request-helper.dart';
import 'package:usadigitizers/app/models/OrderListItem.dart';
import 'package:usadigitizers/basic/button.dart';
import 'package:usadigitizers/basic/dropdown.dart';
import 'package:usadigitizers/basic/text-field.dart';
import 'package:usadigitizers/views/home.dart';
import 'package:usadigitizers/views/layouts/main-layout.dart';

class DigitizingOrderForm extends StatefulWidget {
  Order? order;
  DigitizingOrderForm({this.order});
  @override
  _DigitizingOrderFormState createState() => _DigitizingOrderFormState();
}

@override
class _DigitizingOrderFormState extends State<DigitizingOrderForm> {
  @override
  Widget build(BuildContext context) {
    _loadOrder();
    return Scaffold(
      body: LoadingOverlay(
        isLoading: _isLoading,
        child: SafeArea(
          child: ListView(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 20, top: 20),
                child: Align(
                  child: InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(
                      Icons.arrow_back,
                      size: 40,
                      color: THEME_BLUE,
                    ),
                  ),
                  alignment: Alignment.topLeft,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(
                  left: 20,
                ),
                child: HeadingTextBig(
                    widget.order == null ? "Place Order" : "Edit Order"),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 50, left: 20, right: 20),
                child: Card(
                  elevation: 20,
                  margin: EdgeInsets.only(top: 40),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 50, top: 40),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          CustomTextField(
                            placeholder: 'Name / PO (Required)',
                            controller: this.nameField,
                            maxLines: 1,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Name / PO is required';
                              }
                              return null;
                            },
                          ),
                          CustomDropdown(
                            items: this.formatValues(),
                            placeholder: "Required Format (Required)",
                            onUpdate: this.formatChange,
                            value: this.formatField,
                            validator: (value) {
                              if (value == null) {
                                return 'Required Format is required';
                              }
                              return null;
                            },
                          ),
                          CustomTextField(
                            placeholder: 'Height',
                            controller: this.heightField,
                            maxLines: 1,
                            isNumber: true,
                          ),
                          CustomTextField(
                            placeholder: 'Width',
                            isNumber: true,
                            controller: this.widthField,
                            maxLines: 1,
                          ),
                          CustomDropdown(
                            items: this.fabricValues(),
                            placeholder: "Fabric (Required)",
                            onUpdate: this.fabricChange,
                            value: this.fabricField,
                            validator: (value) {
                              if (value == null) {
                                return 'Fabric is required';
                              }
                              return null;
                            },
                          ),
                          CustomDropdown(
                            items: this.placementValues(),
                            placeholder: "Placement (Required)",
                            onUpdate: this.placementChange,
                            value: this.placementField,
                            validator: (value) {
                              if (value == null) {
                                return 'Placement is required';
                              }
                              return null;
                            },
                          ),
                          CustomTextField(
                            placeholder: 'Number of Colors',
                            controller: this.colorsField,
                            maxLines: 1,
                          ),
                          CustomTextField(
                            placeholder: 'Additional Instructions',
                            controller: this.instructionsField,
                            maxLines: 3,
                          ),
                          Row(
                            children: [
                              Checkbox(
                                onChanged: (dynamic value) {
                                  setState(() {
                                    this.urgentField = value ? 1 : null;
                                  });
                                },
                                value: this.urgentField == 1,
                                activeColor: Color(0xFF6200EE),
                              ),
                              Text(
                                  'Let us know if your order is super urgent!'),
                            ],
                            mainAxisAlignment: MainAxisAlignment.center,
                          ),
                          this.files.length == 0
                              ? Text("No Files Selected!")
                              : Padding(
                                  padding: const EdgeInsets.all(15.0),
                                  child: ListView.builder(
                                    shrinkWrap: true,
                                    physics:
                                        const NeverScrollableScrollPhysics(),
                                    itemCount: this.files.length,
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      return ListTile(
                                        trailing: InkWell(
                                          onTap: () => {removeFile(index)},
                                          child: Icon(
                                            LineIcons.trash,
                                            color: Colors.red,
                                          ),
                                        ),
                                        title: Text(
                                          this.files[index]['name']!,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      );
                                    },
                                  ),
                                ),
                          CustomButton(
                            action: () => {this.selectFiles()},
                            text: "Select Files",
                            hasBorder: true,
                          ),
                          Divider(),
                          CustomButton(
                            action: () => {this.postOrder(context)},
                            text: "Place Order",
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  final _formKey = GlobalKey<FormState>();
  final nameField = new TextEditingController();
  final heightField = new TextEditingController();
  final widthField = new TextEditingController();
  final colorsField = new TextEditingController();
  final instructionsField = new TextEditingController();
  String? formatField;
  String? fabricField;
  String? placementField;
  FilePickerResult? filesPaths;
  dynamic urgentField = 0;
  bool _isLoading = false;
  List<Map<String, String>> files = [];
  void selectFiles() async {
    FilePickerResult? tempFiles =
        await FilePicker.platform.pickFiles(allowMultiple: true);
    setState(() {
      if (tempFiles != null) {
        filesPaths = tempFiles;
        for (int i = 0; i < filesPaths!.files.length; i++) {
          this.files.add({
            "name": filesPaths!.files[i].name,
            "path": filesPaths!.files[i].path ?? ''
          });
        }
      }
    });
  }

  void removeFile(index) {
    setState(() {
      this.files.removeAt(index);
    });
  }

  void fabricChange(value) {
    setState(() {
      this.fabricField = value;
    });
  }

  void placementChange(value) {
    setState(() {
      this.placementField = value;
    });
  }

  void formatChange(value) {
    setState(() {
      this.formatField = value;
    });
  }

  List<DropdownMenuItem<String>> fabricValues() {
    return [
      'Blanket',
      'Canis',
      'Canvas',
      'Cotton Woven',
      'Denim',
      'Felt',
      'Flannel',
      'Fleece',
      'Leather',
      'Nylon',
      'Pique',
      'Polyester',
      'Silk',
      'Single Jersey',
      'Towel',
      'Twill',
      'Others'
    ]
        .map((label) => DropdownMenuItem(
              child: Text(label),
              value: label,
            ))
        .toList();
  }

  List<DropdownMenuItem<String>> placementValues() {
    return [
      'Apron',
      'Bags',
      'Cap',
      'Cap Side',
      'Cap Back',
      'Chest',
      'Gloves',
      'Jacket Back',
      'Patches',
      'Sleeve',
      'Towel',
      'Visor',
      'Others'
    ]
        .map((label) => DropdownMenuItem(
              child: Text(label),
              value: label,
            ))
        .toList();
  }

  List<DropdownMenuItem<String>> formatValues() {
    return [
      '100',
      'cdr',
      'cnd',
      'dsb',
      'dst',
      'dsz',
      'emb',
      'exp',
      'jef',
      'ksm',
      'ofm',
      'pes',
      'pxf',
      'pof',
      'tap',
      'xxx',
      'Others'
    ]
        .map((label) => DropdownMenuItem(
              child: Text(label),
              value: label,
            ))
        .toList();
  }

  void postOrder(BuildContext context) async {
    if (this._formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });
      List<MultipartFile> filesData = [];
      if (this.filesPaths != null) {
        for (var i = 0; i < this.filesPaths!.files.length; i++) {
          PlatformFile e = this.filesPaths!.files[i];
          if (e.path != null) {
            filesData
                .add(await MultipartFile.fromFile(e.path!, filename: e.name));
          }
        }
        print(filesData.length);
      }
      FormData formData = new FormData.fromMap({
        "order_name": this.nameField.text,
        "order_height": this.heightField.text,
        "order_width": this.widthField.text,
        "order_format": this.formatField,
        "order_fabric": this.fabricField,
        "order_placement": this.placementField,
        "order_colors": this.colorsField.text,
        "order_additional_info": this.instructionsField.text,
        "order_urgent": this.urgentField,
        "order_files": filesData
      });
      log(formData.files.toList().toString());
      Dio dio = new RequestHelper().getInstance();
      try {
        Response response = await dio.post(
          '/order/new',
          data: formData,
        );
        if (response.statusCode == 200) {
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (BuildContext context) => MainLayout(index: 0)));
        }
      } on DioError catch (e) {
        if (e.response!.statusCode == 500) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("Cannot connect to the server"),
          ));
        }
      }
    }
  }

  void _loadOrder() {
    void _loadOrder() {
      if (widget.order != null) {
        setState(() {
          nameField.text = widget.order!.orderName ?? '';
          heightField.text = widget.order!.orderHeight ?? '';
          widthField.text = widget.order!.orderWidth ?? '';
          formatField = widget.order!.orderFormat ?? '';
          fabricField = widget.order!.orderFabric ?? '';
          placementField = widget.order!.orderPlacement ?? '';
          colorsField.text = widget.order!.orderColors ?? '';
          instructionsField.text = widget.order!.orderAdditionalInfo ?? '';
          urgentField = widget.order!.orderUrgent ?? false;
        });
      }
    }

    @override
    Widget build(BuildContext context) {
      _loadOrder();
      return Scaffold(
        body: LoadingOverlay(
          isLoading: _isLoading,
          child: SafeArea(
            child: ListView(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 20, top: 20),
                  child: Align(
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Icon(
                        Icons.arrow_back,
                        size: 40,
                        color: THEME_BLUE,
                      ),
                    ),
                    alignment: Alignment.topLeft,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 20,
                  ),
                  child: HeadingTextBig(
                      widget.order == null ? "Place Order" : "Edit Order"),
                ),
                Padding(
                  padding:
                      const EdgeInsets.only(bottom: 50, left: 20, right: 20),
                  child: Card(
                    elevation: 20,
                    margin: EdgeInsets.only(top: 40),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 50, top: 40),
                      child: Form(
                        child: Form(
                          key: _formKey,
                          child: Column(
                            children: [
                              CustomTextField(
                                placeholder: 'Name / PO (Required)',
                                controller: this.nameField,
                                maxLines: 1,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Name / PO is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomDropdown(
                                items: this.formatValues(),
                                placeholder: "Required Format (Required)",
                                onUpdate: this.formatChange,
                                value: this.formatField,
                                validator: (value) {
                                  if (value == null) {
                                    return 'Required Format is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomTextField(
                                placeholder: 'Height',
                                controller: this.heightField,
                                maxLines: 1,
                                isNumber: true,
                              ),
                              CustomTextField(
                                placeholder: 'Width',
                                isNumber: true,
                                controller: this.widthField,
                                maxLines: 1,
                              ),
                              CustomDropdown(
                                items: this.fabricValues(),
                                placeholder: "Fabric (Required)",
                                onUpdate: this.fabricChange,
                                value: this.fabricField,
                                validator: (value) {
                                  if (value == null) {
                                    return 'Fabric is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomDropdown(
                                items: this.placementValues(),
                                placeholder: "Placement (Required)",
                                onUpdate: this.placementChange,
                                value: this.placementField,
                                validator: (value) {
                                  if (value == null) {
                                    return 'Placement is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomTextField(
                                placeholder: 'Number of Colors',
                                controller: this.colorsField,
                                maxLines: 1,
                              ),
                              CustomTextField(
                                placeholder: 'Additional Instructions',
                                controller: this.instructionsField,
                                maxLines: 3,
                              ),
                              Row(
                                children: [
                                  Checkbox(
                                    onChanged: (dynamic value) {
                                      setState(() {
                                        this.urgentField = value ? 1 : null;
                                      });
                                    },
                                    value: this.urgentField == 1,
                                    activeColor: Color(0xFF6200EE),
                                  ),
                                  Text(
                                      'Let us know if your order is super urgent!'),
                                ],
                                mainAxisAlignment: MainAxisAlignment.center,
                              ),
                              this.files.length == 0
                                  ? Text("No Files Selected!")
                                  : Padding(
                                      padding: const EdgeInsets.all(15.0),
                                      child: ListView.builder(
                                        shrinkWrap: true,
                                        physics:
                                            const NeverScrollableScrollPhysics(),
                                        itemCount: this.files.length,
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          return ListTile(
                                            trailing: InkWell(
                                              onTap: () => {removeFile(index)},
                                              child: Icon(
                                                LineIcons.trash,
                                                color: Colors.red,
                                              ),
                                            ),
                                            title: Text(
                                              this.files[index]['name']!,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                              CustomButton(
                                action: () => {this.selectFiles()},
                                text: "Select Files",
                                hasBorder: true,
                              ),
                              Divider(),
                              CustomButton(
                                action: () => {this.postOrder(context)},
                                text: "Place Order",
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }
  }
}
