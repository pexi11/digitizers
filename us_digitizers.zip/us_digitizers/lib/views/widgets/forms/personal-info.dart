import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:usadigitizers/app/helpers/constants.dart';
import 'package:usadigitizers/app/helpers/request-helper.dart';
import 'package:usadigitizers/app/models/Customer.dart';
import 'package:usadigitizers/app/models/User.dart';
import 'package:usadigitizers/basic/button.dart';
import 'package:usadigitizers/basic/dropdown.dart';
import 'package:usadigitizers/basic/text-field.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:usadigitizers/views/home.dart';

class PersonalInfo extends StatefulWidget {
  @override
  _PersonalInfoState createState() => _PersonalInfoState();
}

class _PersonalInfoState extends State<PersonalInfo> {
  final _formKey = GlobalKey<FormState>();
  var maskFormatter = new MaskTextInputFormatter(
      mask: '(###) ###-####', filter: {"#": RegExp(r'[0-9]')});
  final name = new TextEditingController();
  final company = new TextEditingController();
  String? companyType;
  final phone = new TextEditingController();
  final cell = new TextEditingController();
  final fax = new TextEditingController();
  final email1 = new TextEditingController();
  final email2 = new TextEditingController();
  final email3 = new TextEditingController();
  final email4 = new TextEditingController();
  final address = new TextEditingController();
  final city = new TextEditingController();
  final state = new TextEditingController();
  final zipcode = new TextEditingController();
  final username = new TextEditingController();
  int? country;
  String? countryString;
  final password = new TextEditingController();
  List<DropdownMenuItem<String>> countryList = [];
  bool _isLoading = false;

  Future _loadData() async {
    setState(() {
      _isLoading = true;
    });
    Dio dio = RequestHelper().getInstance();
    Response response = await dio.get('/profile/get');
    if (response.statusCode == 200) {
      User user = User.fromJson(response.data);
      Customer customer = Customer.fromJson(response.data['customer']);
      setState(() {
        name.text = user.name;
        company.text = customer.customerCompany;
        companyType = customer.customerCompanyType;
        phone.text = customer.customerPhone;
        cell.text = customer.customerCell;
        fax.text = customer.customerFax;
        email1.text = user.email;
        email2.text = customer.customerEmail2;
        email3.text = customer.customerEmail3;
        email4.text = customer.customerEmail4;
        address.text = customer.customerAddress;
        city.text = customer.customerCity;
        state.text = customer.customerState;
        username.text = user.username;
        country = customer.customerCountry;
        _isLoading = false;
      });
    } else {}
  }

  void updateProfile(BuildContext context) async {
    if (this._formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });
      FormData formData = new FormData.fromMap({
        "name": this.name.text,
        "email": this.email1.text,
        "password": this.password.text,
        "customer[customer_company]": this.company.text,
        "customer[customer_company_type]": this.companyType,
        "customer[customer_phone]": this.phone.text,
        "customer[customer_cell]": this.cell.text,
        "customer[customer_fax]": this.fax.text,
        "customer[customer_email2]": this.email2.text,
        "customer[customer_email3]": this.email3.text,
        "customer[customer_email4]": this.email4.text,
        "customer[customer_address]": this.address.text,
        "customer[customer_state]": this.state.text,
        "customer[customer_city]": this.city.text,
        "customer[customer_zipcode]": this.zipcode.text,
        "customer[customer_country]":
            this.countryString != null ? int.parse(this.countryString!) : null,
      });

      Dio dio = new RequestHelper().getInstance();
      Response response = Response(requestOptions: RequestOptions(path: ''));
      try {
        response = await dio.post(
          '/profile/update',
          data: formData,
        );
      } on DioError catch (e) {
        if (e.type == DioErrorType.connectionTimeout) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("Cannot connect to the server"),
          ));
        }
        if (e.type == DioErrorType.badResponse) {
          if (e.response?.statusCode == 422) {
            ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(e.response?.data['errors'].first)));
          }
        }
        print("in catch");
      }
      setState(() {
        _isLoading = false;
      });
      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Profile updated successfully!")));
      }
    }
  }

  Future _loadCountries() async {
    Dio dio = RequestHelper().getInstance();
    Response response = await dio.get('/countries');
    if (response.statusCode == 200) {
      Map<String, dynamic>.from(response.data).forEach((key, value) {
        setState(() {
          countryList.add(
            DropdownMenuItem(
              child: Text(value),
              value: key,
            ),
          );
        });
      });
    }
  }

  List<DropdownMenuItem<String>> companyTypes() {
    return [
      "Embroider",
      "Distributor",
      "Promotional",
      "Marketing",
      "Manufacturers",
      "Uniform/Apparels",
      "Other"
    ]
        .map(
          (e) => DropdownMenuItem(
            child: Text(e),
            value: e,
          ),
        )
        .toList();
  }

  void companyTypeChange(value) {
    setState(() {
      this.companyType = value;
    });
  }

  void countryChange(value) {
    setState(() {
      this.country = value;
    });
  }

  @override
  void initState() {
    super.initState();
    _loadData();
    _loadCountries();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LoadingOverlay(
        isLoading: _isLoading,
        child: Builder(builder: (context) {
          return SafeArea(
            child: ListView(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 20, top: 20),
                  child: Align(
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Icon(
                        Icons.arrow_back,
                        size: 40,
                        color: THEME_BLUE,
                      ),
                    ),
                    alignment: Alignment.topLeft,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 20,
                  ),
                  child: HeadingTextBig("Personal Info"),
                ),
                Padding(
                  padding:
                      const EdgeInsets.only(bottom: 50, left: 20, right: 20),
                  child: Card(
                    elevation: 20,
                    margin: EdgeInsets.only(top: 40),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 50, top: 40),
                      child: Form(
                        child: Form(
                          key: _formKey,
                          child: Column(
                            children: [
                              CustomTextField(
                                placeholder: 'Contact Name (required)',
                                controller: this.name,
                                maxLines: 1,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Contact Name is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomTextField(
                                placeholder: 'Company Name (required)',
                                controller: this.company,
                                maxLines: 1,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Company Name is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomDropdown(
                                items: this.companyTypes(),
                                placeholder: "Company Type (Required)",
                                onUpdate: this.companyTypeChange,
                                value: this.companyType,
                                validator: (value) {
                                  if (value == null) {
                                    return 'Company Type is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomTextField(
                                placeholder: 'Phone (required)',
                                controller: this.phone,
                                maxLines: 1,
                                formatter: [maskFormatter],
                                isNumber: true,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Phone is required';
                                  }
                                  return null;
                                },
                              ),
                              CustomTextField(
                                placeholder: 'Cell',
                                formatter: [maskFormatter],
                                isNumber: true,
                                controller: this.cell,
                                maxLines: 1,
                              ),
                              CustomTextField(
                                placeholder: 'Fax',
                                formatter: [maskFormatter],
                                isNumber: true,
                                controller: this.fax,
                                maxLines: 1,
                              ),
                              CustomTextField(
                                placeholder: 'Email (required)',
                                controller: this.email1,
                                maxLines: 1,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Email 1 is required';
                                  }
                                  Pattern pattern =
                                      r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
                                  RegExp regex = new RegExp(pattern.toString());
                                  if (!(regex.hasMatch(value)))
                                    return "Invalid Email";
                                  return null;
                                },
                              ),
                              CustomTextField(
                                placeholder: 'Email 2',
                                controller: this.email2,
                                maxLines: 1,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    Pattern pattern =
                                        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
                                    RegExp regex =
                                        new RegExp(pattern.toString());
                                    if (!(regex.hasMatch(value)))
                                      return "Invalid Email";
                                  }
                                  return null;
                                },
                              ),
                              CustomTextField(
                                  placeholder: 'Email 3',
                                  controller: this.email3,
                                  maxLines: 1,
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      Pattern pattern =
                                          r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
                                      RegExp regex =
                                          new RegExp(pattern.toString());
                                      if (!(regex.hasMatch(value)))
                                        return "Invalid Email";
                                    }
                                    return null;
                                  }),
                              CustomTextField(
                                  placeholder: 'Email 4',
                                  controller: this.email4,
                                  maxLines: 1,
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      Pattern pattern =
                                          r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
                                      RegExp regex =
                                          new RegExp(pattern.toString());
                                      if (!(regex.hasMatch(value)))
                                        return "Invalid Email";
                                    }
                                    return null;
                                  }),
                              CustomTextField(
                                placeholder: 'Address',
                                controller: this.address,
                                maxLines: 3,
                              ),
                              CustomTextField(
                                placeholder: 'City',
                                controller: this.city,
                                maxLines: 1,
                              ),
                              CustomTextField(
                                placeholder: 'State',
                                controller: this.state,
                                maxLines: 1,
                              ),
                              CustomTextField(
                                placeholder: 'Zipcode',
                                controller: this.zipcode,
                                maxLines: 1,
                              ),
                              CustomDropdown(
                                items: this.countryList,
                                placeholder: "Country",
                                onUpdate: this.countryChange,
                                value: this.countryString,
                              ),
                              CustomTextField(
                                placeholder: 'Username',
                                controller: this.username,
                                enabled: false,
                                maxLines: 1,
                              ),
                              CustomTextField(
                                placeholder: 'Password',
                                controller: this.password,
                                maxLines: 1,
                              ),
                              CustomButton(
                                action: () => {this.updateProfile(context)},
                                text: "Update Profile",
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}
