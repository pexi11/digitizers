import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:usadigitizers/app/helpers/constants.dart';
import 'package:usadigitizers/auth/login.dart';
import 'package:usadigitizers/views/widgets/forms/billing-info.dart';
import 'package:usadigitizers/views/widgets/forms/personal-info.dart';

class Profile extends StatelessWidget {
  void logout(context) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    pref.remove("user");
    pref.remove("accessToken");
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => Login()),
    );
  }

  void sendToPersonal(context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => PersonalInfo()),
    );
  }

  void sendToBilling(context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => BillingInfo()),
    );
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            width: double.infinity,
            height: 250 + MediaQuery.of(context).padding.top,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(40),
                  bottomRight: Radius.circular(40)),
              gradient: LinearGradient(
                colors: [THEME_BLUE, THEME_RED],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
            ),
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.only(top: 10),
                  width: double.infinity,
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).padding.top),
                    child: Center(
                      child: Text(
                        "My Profile",
                        style: TextStyle(
                          shadows: <Shadow>[
                            Shadow(
                              offset: Offset(0, 0),
                              blurRadius: 5.0,
                              color: Color.fromARGB(255, 255, 255, 255),
                            )
                          ],
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                  height: 100,
                  width: 100,
                  margin: EdgeInsets.only(top: 30),
                  child: Icon(
                    LineIcons.user,
                    color: Colors.white,
                    size: 35,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white30,
                    borderRadius: BorderRadius.all(Radius.circular(50)),
                  ),
                ),
              ],
            ),
          ),
          Container(
            alignment: Alignment.center,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: <BoxShadow>[
                  BoxShadow(color: Color.fromRGBO(0, 0, 0, 0.8))
                ],
                borderRadius: BorderRadius.all(Radius.circular(35)),
              ),
              child: Padding(
                padding: const EdgeInsets.all(15),
                child: Text(
                  authUser.name ?? "user name",
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
              ),
              height: 60,
              width: 250,
            ),
            width: double.infinity,
            height: 70,
            margin:
                EdgeInsets.only(top: 210 + MediaQuery.of(context).padding.top),
          ),
          Container(
            margin: EdgeInsets.only(top: 340),
            child: Column(
              children: [
                ProfileItem(
                  icon: LineIcons.user,
                  text: "Personal Info",
                  action: () {
                    this.sendToPersonal(context);
                  },
                ),
                ProfileItem(
                  icon: LineIcons.creditCard,
                  text: "Billing Info",
                  action: () {
                    this.sendToBilling(context);
                  },
                ),
                ProfileItem(
                  icon: LineIcons.dolly,
                  text: "Invoices",
                  action: () {},
                ),
                ProfileItem(
                  icon: LineIcons.paragraph,
                  text: "Terms & Conditions",
                  action: () {},
                ),
                Center(
                  child: InkWell(
                    onTap: () {
                      this.logout(context);
                    },
                    child: Container(
                      margin: EdgeInsets.only(top: 20),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(25),
                          border: Border.all(
                            color: THEME_BLUE,
                            width: 2,
                          )),
                      child: Padding(
                        padding: const EdgeInsets.only(
                            top: 10, left: 25, right: 25, bottom: 10),
                        child: Text(
                          "Logout",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: THEME_BLUE,
                          ),
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}

class ProfileItem extends StatelessWidget {
  const ProfileItem(
      {Key? key, required this.icon, required this.text, required this.action})
      : super(key: key);
  final IconData icon;
  final String text;
  final VoidCallback action;
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        decoration: BoxDecoration(
          border: Border(
              bottom: BorderSide(
            color: Colors.black12,
            width: 1,
          )),
        ),
        width: 280,
        alignment: Alignment.center,
        child: InkWell(
          onTap: action,
          child: Padding(
            padding: const EdgeInsets.only(top: 20, bottom: 20),
            child: Row(
              children: [
                Container(
                  width: 50,
                  child: Icon(
                    icon,
                    color: THEME_BLUE,
                    size: 20,
                  ),
                ),
                Text(
                  text,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: THEME_BLUE,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
