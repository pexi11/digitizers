import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:usadigitizers/app/helpers/constants.dart';
import 'package:usadigitizers/app/helpers/request-helper.dart';
import 'package:usadigitizers/app/models/FileModel.dart';
import 'package:usadigitizers/app/models/OrderListItem.dart';
import 'package:usadigitizers/basic/button.dart';
import 'package:usadigitizers/views/home.dart';
import 'package:usadigitizers/views/widgets/forms/digitizing-order.dart';

class OrderDetail extends StatefulWidget {
  final Order order;
  OrderDetail({required this.order});

  @override
  _OrderDetailState createState() => _OrderDetailState();
}

class _OrderDetailState extends State<OrderDetail> {
  List<FileModel> files = [];
  String progress = '0';
  bool isDownloaded = false;
  bool isLoaded = false;
  bool canEdit = false;
  Future _loadData() async {
    Dio dio = RequestHelper().getInstance();
    Response response =
        await dio.get('/order/files?id=' + widget.order.orderId.toString());
    if (response.statusCode == 200) {
      setState(() {
        this.isLoaded = true;
        this.files =
            (response.data as List).map((e) => FileModel.fromJson(e)).toList();
      });
    }

    // Can Edit
    Response editResponse =
        await dio.get('/order/can-edit/' + widget.order.orderId.toString());
    if (editResponse.statusCode == 200) {
      if (editResponse.data["can_edit"] == true) {
        setState(() {
          canEdit = true;
        });
      }
    }
  }

  void editOrder(context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => DigitizingOrderForm(
          order: widget.order,
        ),
      ),
    );
  }

  Future<String> getFilePath(uniqueFileName) async {
    String path = '';
    Directory dir = await getApplicationDocumentsDirectory();
    path = '${dir.path}/$uniqueFileName';
    return path;
  }

  Future<void> downloadFile(uri, fileName) async {
    String savePath = await getFilePath(fileName);
    try {
      OpenResult result = await OpenFile.open(savePath);
      if (result.type == ResultType.fileNotFound)
        throw new Exception("download file");
    } catch (e) {
      Dio dio = Dio();
      dio.download(
        uri,
        savePath,
        onReceiveProgress: (rcv, total) {
          setState(() {
            progress = ((rcv / total) * 100).toStringAsFixed(0);
          });
          if (progress == '100') {
            setState(() {
              isDownloaded = true;
            });
          } else if (double.parse(progress) < 100) {}
        },
        deleteOnError: true,
      ).then((_) async {
        setState(() {
          if (progress == '100') {
            isDownloaded = true;
          }
        });
        String savePath = await getFilePath(fileName);
        OpenFile.open(savePath);
      });
    }
  }

  @override
  void initState() {
    super.initState();
    this._loadData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 20, top: 20),
            child: Align(
              child: InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Icon(
                  Icons.arrow_back,
                  size: 40,
                  color: THEME_BLUE,
                ),
              ),
              alignment: Alignment.topLeft,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(
              left: 20,
            ),
            child: HeadingTextBig("Order Details"),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 50, left: 20, right: 20),
            child: Container(
              width: double.infinity,
              child: Card(
                elevation: 20,
                margin: EdgeInsets.only(top: 40),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                child: Padding(
                  padding: EdgeInsets.all(30),
                  child: Column(
                    children: [
                      DetailItem("Order #", widget.order.orderNo),
                      DetailItem("Design Name/PO", widget.order.orderName),
                      DetailItem("Height", widget.order.orderHeight),
                      DetailItem("Width", widget.order.orderWidth),
                      DetailItem("Status", widget.order.orderStatus),
                      DetailItem("No of Colors", widget.order.orderColors),
                      DetailItem("Format", widget.order.orderFormat),
                      DetailItem("Fabric", widget.order.orderFabric),
                      DetailItem("Received Date",
                          dateFormatHelper(widget.order.createdAt)),
                      DetailItem("Released Date",
                          dateFormatHelper(widget.order.orderReleaseDate)),
                      Text("Files"),
                      if (isLoaded)
                        ListView.builder(
                          itemCount: files.length,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) => Container(
                            child: ListTile(
                              title: Text('${files[index].filename}'),
                              onTap: () => this.downloadFile(
                                  '${files[index].url}',
                                  '${files[index].filename}'),
                            ),
                          ),
                        ),
                      if (isLoaded && files.length == 0) Text("No files found"),
                      if (canEdit)
                        Container(
                          child: EditButton(
                            text: "Edit",
                            action: () => {this.editOrder(context)},
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class DetailItem extends StatelessWidget {
  final String name;
  final dynamic value;
  const DetailItem(this.name, this.value);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: double.infinity,
          child: Text(
            this.name + " ",
            textAlign: TextAlign.left,
            style: TextStyle(color: THEME_RED),
          ),
        ),
        Container(
          width: double.infinity,
          child: Text(
            this.value == null ? "" : this.value.toString(),
            textAlign: TextAlign.left,
            style: TextStyle(color: THEME_BLUE),
          ),
        ),
        Divider(
          color: Colors.black26,
        )
      ],
    );
  }
}
