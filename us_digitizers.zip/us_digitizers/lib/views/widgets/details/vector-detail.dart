import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:usadigitizers/app/helpers/constants.dart';
import 'package:usadigitizers/app/helpers/request-helper.dart';
import 'package:usadigitizers/app/models/FileModel.dart';
import 'package:usadigitizers/app/models/VectorListItem.dart';
import 'package:usadigitizers/views/home.dart';
import 'package:usadigitizers/views/widgets/details/order-detail.dart';

class VectorDetail extends StatefulWidget {
  final Vector vector;
  VectorDetail({required this.vector});

  @override
  _VectorDetailState createState() => _VectorDetailState();
}

class _VectorDetailState extends State<VectorDetail> {
  List<FileModel> files = [];
  String progress = '0';
  bool isDownloaded = false;
  bool downloading = false;
  Future _loadData() async {
    Dio dio = RequestHelper().getInstance();
    Response response =
        await dio.get('/vector/files?id=' + widget.vector.vectorId.toString());
    if (response.statusCode == 200) {
      setState(() {
        // this.isLoading = false;
        this.files =
            (response.data as List).map((e) => FileModel.fromJson(e)).toList();
      });
    }
  }

  Future<String> getFilePath(uniqueFileName) async {
    String path = '';

    Directory dir = await getApplicationDocumentsDirectory();

    path = '${dir.path}/$uniqueFileName';

    return path;
  }

  Future<void> downloadFile(uri, fileName) async {
    setState(() {
      downloading = true;
    });

    String savePath = await getFilePath(fileName);
    Dio dio = Dio();
    dio.download(
      uri,
      savePath,
      onReceiveProgress: (rcv, total) {
        setState(() {
          progress = ((rcv / total) * 100).toStringAsFixed(0);
        });
        if (progress == '100') {
          setState(() {
            isDownloaded = true;
          });
        } else if (double.parse(progress) < 100) {}
      },
      deleteOnError: true,
    ).then((_) async {
      setState(() {
        if (progress == '100') {
          isDownloaded = true;
        }
        downloading = false;
      });
      String savePath = await getFilePath(fileName);
      OpenFile.open(savePath);
    });
  }

  @override
  void initState() {
    super.initState();
    this._loadData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 20, top: 20),
              child: Align(
                child: InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Icon(
                    Icons.arrow_back,
                    size: 40,
                    color: THEME_BLUE,
                  ),
                ),
                alignment: Alignment.topLeft,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                left: 20,
              ),
              child: HeadingTextBig("Quote Details"),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 50, left: 20, right: 20),
              child: Container(
                width: double.infinity,
                child: Card(
                  elevation: 20,
                  margin: EdgeInsets.only(top: 40),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                  child: Padding(
                    padding: EdgeInsets.all(30),
                    child: Column(
                      children: [
                        DetailItem("Quote #", widget.vector.vectorNo),
                        DetailItem("Design Name/PO", widget.vector.vectorName),
                        DetailItem("Status", widget.vector.vectorStatus),
                        DetailItem("No of Colors", widget.vector.vectorColors),
                        DetailItem("Format", widget.vector.vectorFormat),
                        DetailItem("Received Date", widget.vector.createdAt),
                        DetailItem(
                            "Released Date", widget.vector.vectorReleaseDate),
                        Text("Files"),
                        ListView.builder(
                          itemCount: files.length,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) => Card(
                            child: InkWell(
                              child: Text('${files[index].filename}'),
                              onTap: () => this.downloadFile(
                                  '${files[index].url}',
                                  '${files[index].filename}'),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
