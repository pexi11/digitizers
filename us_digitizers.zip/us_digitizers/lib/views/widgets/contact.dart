import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
import 'package:usadigitizers/app/helpers/constants.dart';

class ContactForm extends StatefulWidget {
  @override
  _ContactFormState createState() => _ContactFormState();
}

class _ContactFormState extends State<ContactForm> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            width: double.infinity,
            height: 250 + MediaQuery.of(context).padding.top,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(20)),
              gradient: LinearGradient(
                colors: [THEME_BLUE, THEME_RED],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
            ),
            child: Padding(
              padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 10),
                    width: double.infinity,
                    child: Center(
                      child: Text(
                        "Contact Us",
                        style: TextStyle(
                          shadows: <Shadow>[
                            Shadow(
                              offset: Offset(0, 0),
                              blurRadius: 5.0,
                              color: Color.fromARGB(255, 255, 255, 255),
                            )
                          ],
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    margin: EdgeInsets.only(top: 30),
                    child: Icon(
                      LineIcons.envelope,
                      color: Colors.white,
                      size: 35,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white30,
                      borderRadius: BorderRadius.all(Radius.circular(50)),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(
              top: 220 + MediaQuery.of(context).padding.top,
              left: 45,
              right: 45,
            ),
            child: Column(
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(30),
                    child: TextFormField(
                      autocorrect: false,
                      maxLines: 10,
                      decoration: new InputDecoration.collapsed(
                          hintText: 'Enter your message here...'),
                    ),
                  ),
                ),
                ElevatedButton.icon(
                    onPressed: null,
                    icon: Icon(LineIcons.paperPlane),
                    label: Text("Send Now")),
              ],
            ),
          )
        ],
      ),
    );
  }
}
