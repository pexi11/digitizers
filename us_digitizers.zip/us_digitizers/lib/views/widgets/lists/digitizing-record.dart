import 'package:loadmore/loadmore.dart';
import 'package:shimmer/shimmer.dart';
import 'package:badges/badges.dart' as badge;
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
import 'package:usadigitizers/app/helpers/constants.dart';
import 'package:usadigitizers/app/helpers/request-helper.dart';
import 'package:usadigitizers/app/models/OrderListItem.dart';
import 'package:usadigitizers/views/widgets/details/order-detail.dart';

class DigitizingRecord extends StatefulWidget {
  @override
  _DigitizingRecordState createState() => _DigitizingRecordState();
}

class _DigitizingRecordState extends State<DigitizingRecord> {
  List<Order> items = ORDER_ITEMS == null ? [] : ORDER_ITEMS;
  TextEditingController editingController = TextEditingController();
  bool isLoading = ORDER_ITEMS == null;
  Future<bool> _loadData() async {
    setState(() {
      ++orderPageNumber;
    });
    Dio dio = RequestHelper().getInstance();
    Response response =
        await dio.get('/order/list?page=' + orderPageNumber.toString());
    if (response.statusCode == 200) {
      setState(() {
        this.isLoading = false;
        List<Order> newLoaded = (response.data['data'] as List)
            .map((e) => Order.fromJson(e))
            .toList();
        items.addAll(newLoaded);
        ORDER_ITEMS = []..addAll(items);
      });
      orderTotalRecords = response.data["total"];
      return true;
    }
    return false;
  }

  void filterSearchResults(String query) {}

  @override
  void initState() {
    super.initState();
    this._loadData();
  }

  @override
  void setState(fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding:
              const EdgeInsets.only(top: 10, bottom: 10, left: 20, right: 20),
          child: TextField(
            onChanged: (value) {
              filterSearchResults(value);
            },
            controller: editingController,
            decoration: InputDecoration(
                isDense: true,
                labelText: "Search",
                hintText: "Search",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(50.0)))),
          ),
        ),
        if (this.isLoading)
          Expanded(
              child: Padding(
            padding: EdgeInsets.all(20),
            child: Shimmer.fromColors(
              baseColor: Colors.grey.shade300,
              highlightColor: Colors.grey.shade100,
              child: ListView.builder(
                itemBuilder: (_, __) => Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 48.0,
                        height: 48.0,
                        color: Colors.white,
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8.0),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              width: double.infinity,
                              height: 8.0,
                              color: Colors.white,
                            ),
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 2.0),
                            ),
                            Container(
                              width: double.infinity,
                              height: 8.0,
                              color: Colors.white,
                            ),
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 2.0),
                            ),
                            Container(
                              width: 40.0,
                              height: 8.0,
                              color: Colors.white,
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                itemCount: 6,
              ),
            ),
          )),
        Expanded(
          child: LoadMore(
            isFinish: orderPageNumber > 0 && items.length >= orderTotalRecords,
            onLoadMore: _loadData,
            textBuilder: (status) => "",
            child: ListView.builder(
              itemCount: items.length,
              itemBuilder: (context, index) {
                return Card(
                  elevation: 0,
                  margin: EdgeInsets.only(left: 20, right: 20),
                  child: InkWell(
                    onTap: () => {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => OrderDetail(
                            order: items[index],
                          ),
                        ),
                      )
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                                width: index != items.length - 1 ? 1 : 0,
                                color: Colors.black12),
                          ),
                        ),
                        child: ListTile(
                          title: Text('${items[index].orderNo}'),
                          subtitle: Column(
                            children: [
                              Container(
                                child: Text(
                                  '${items[index].orderName}',
                                  textAlign: TextAlign.left,
                                ),
                                width: double.infinity,
                              ),
                              Row(
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(right: 5),
                                    child: badge.Badge(
                                      badgeStyle: badge.BadgeStyle(
                                        badgeColor: THEME_BLUE,
                                        padding: EdgeInsets.all(5),
                                        shape: badge.BadgeShape.square,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      badgeContent: Text(
                                        '${items[index].orderStatus.toUpperCase()}',
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 8),
                                      ),
                                    ),
                                  ),
                                  badge.Badge(
                                    badgeStyle: badge.BadgeStyle(
                                      badgeColor: THEME_RED,
                                      padding: EdgeInsets.all(5),
                                      shape: badge.BadgeShape.square,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    badgeContent: Text(
                                      '${items[index].orderPaymentStatus.toUpperCase()}',
                                      style: TextStyle(
                                          color: Colors.white, fontSize: 8),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          trailing: Icon(LineIcons.angleRight),
                          isThreeLine: true,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        )
      ],
    );
  }
}
