import 'package:loadmore/loadmore.dart';
import 'package:shimmer/shimmer.dart';
import 'package:badges/badges.dart' as badge;
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
import 'package:usadigitizers/app/helpers/constants.dart';
import 'package:usadigitizers/app/helpers/request-helper.dart';
import 'package:usadigitizers/app/models/VectorListItem.dart';
import 'package:usadigitizers/views/widgets/details/vector-detail.dart';

class VectorRecord extends StatefulWidget {
  @override
  _VectorRecordState createState() => _VectorRecordState();
}

class _VectorRecordState extends State<VectorRecord> {
  List<Vector> items = VECTOR_ITEMS == null ? [] : VECTOR_ITEMS;
  TextEditingController editingController = TextEditingController();
  bool isLoading = VECTOR_ITEMS == null;
  Future<bool> _loadData() async {
    setState(() {
      ++vectorPageNumber;
    });
    Dio dio = RequestHelper().getInstance();
    Response response =
        await dio.get('/vector/list?page=' + vectorPageNumber.toString());
    if (response.statusCode == 200) {
      setState(() {
        this.isLoading = false;
        List<Vector> newLoaded = (response.data['data'] as List)
            .map((e) => Vector.fromJson(e))
            .toList();
        items.addAll(newLoaded);
        VECTOR_ITEMS = []..addAll(items);
      });
      vectorTotalRecords = response.data["total"];
      return true;
    }
    return false;
  }

  @override
  void setState(fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  void filterSearchResults(String query) {}

  @override
  void initState() {
    super.initState();
    this._loadData();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding:
              const EdgeInsets.only(top: 10, bottom: 10, left: 20, right: 20),
          child: TextField(
            onChanged: (value) {
              filterSearchResults(value);
            },
            controller: editingController,
            decoration: InputDecoration(
                isDense: true,
                labelText: "Search",
                hintText: "Search",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(50.0)))),
          ),
        ),
        if (this.isLoading)
          Expanded(
              child: Padding(
            padding: EdgeInsets.all(20),
            child: Shimmer.fromColors(
              baseColor: Colors.grey.shade300,
              highlightColor: Colors.grey.shade100,
              child: ListView.builder(
                itemBuilder: (_, __) => Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 48.0,
                        height: 48.0,
                        color: Colors.white,
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8.0),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              width: double.infinity,
                              height: 8.0,
                              color: Colors.white,
                            ),
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 2.0),
                            ),
                            Container(
                              width: double.infinity,
                              height: 8.0,
                              color: Colors.white,
                            ),
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 2.0),
                            ),
                            Container(
                              width: 40.0,
                              height: 8.0,
                              color: Colors.white,
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                itemCount: 6,
              ),
            ),
          )),
        Expanded(
          child: LoadMore(
            isFinish:
                vectorPageNumber > 0 && items.length >= vectorTotalRecords,
            onLoadMore: _loadData,
            textBuilder: (status) => "",
            child: ListView.builder(
              itemCount: items.length,
              itemBuilder: (context, index) {
                return Card(
                  elevation: 0,
                  margin: EdgeInsets.only(left: 20, right: 20),
                  child: InkWell(
                    onTap: () => {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => VectorDetail(
                            vector: items[index],
                          ),
                        ),
                      )
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                                width: index != items.length - 1 ? 1 : 0,
                                color: Colors.black12),
                          ),
                        ),
                        child: ListTile(
                          title: Text('${items[index].vectorNo}'),
                          subtitle: Column(
                            children: [
                              Container(
                                child: Text(
                                  '${items[index].vectorName}',
                                  textAlign: TextAlign.left,
                                ),
                                width: double.infinity,
                              ),
                              Row(
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(right: 5),
                                    child: badge.Badge(
                                      badgeStyle: badge.BadgeStyle(
                                        badgeColor: THEME_BLUE,
                                        padding: EdgeInsets.all(5),
                                        shape: badge.BadgeShape.square,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      badgeContent: Text(
                                        '${items[index].vectorStatus.toUpperCase()}',
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 8),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          trailing: Icon(LineIcons.angleRight),
                          isThreeLine: true,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        )
      ],
    );
  }
}
