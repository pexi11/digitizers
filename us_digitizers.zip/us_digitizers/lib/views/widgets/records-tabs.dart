import 'package:flutter/material.dart';
import 'package:usadigitizers/views/widgets/lists/digitizing-record.dart';
import 'package:usadigitizers/views/widgets/lists/quote-record.dart';
import 'package:usadigitizers/views/widgets/lists/vector-record.dart';

class RecordsTabs extends StatefulWidget {
  @override
  _RecordsTabsState createState() => _RecordsTabsState();
}

class _RecordsTabsState extends State<RecordsTabs> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text("Records"),
          bottom: TabBar(
            tabs: [
              Tab(icon: Text("Orders")),
              Tab(icon: Text("Quotes")),
              Tab(icon: Text("Vectors")),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            DigitizingRecord(),
            QuoteRecord(),
            VectorRecord(),
          ],
        ),
      ),
    );
  }
}
