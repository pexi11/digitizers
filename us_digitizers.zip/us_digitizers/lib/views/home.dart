import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:usadigitizers/app/helpers/request-helper.dart';
import 'package:usadigitizers/app/models/OrderListItem.dart';
import 'package:usadigitizers/app/models/QuoteListItem.dart';
import 'package:usadigitizers/app/models/VectorListItem.dart';
import 'package:usadigitizers/auth/login.dart';
import 'package:usadigitizers/views/widgets/details/order-detail.dart';
import 'package:usadigitizers/views/widgets/details/quote-detail.dart';
import 'package:usadigitizers/views/widgets/details/vector-detail.dart';
import '../app/helpers/constants.dart' as Constants;

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  late BuildContext context;
  List<Order> orders = Constants.HOME_ORDER_ITEMS;
  List<Quote> quotes = Constants.HOME_QUOTE_ITEMS;
  List<Vector> vectors = Constants.HOME_VECTOR_ITEMS;
  Future _loadData() async {
    Dio dio = RequestHelper().getInstance();
    Response response = await dio.get('/home');
    if (response.statusCode == 200) {
      final data = response.data;
      setState(() {
        orders = (data['orders'] as List)
            .map((item) => Order.fromJson(item))
            .toList();
        quotes = (data['quotes'] as List)
            .map((item) => Quote.fromJson(item))
            .toList();
        vectors = (data['vectors'] as List)
            .map((item) => Vector.fromJson(item))
            .toList();
      });
    } else {
      // Handle error
      print('Failed to load data: ${response.statusCode}');
    }
    if (response != null) {
      setState(() {
        this.orders = (response.data["order"] as List)
            .map((e) => Order.fromJson(e))
            .toList();
        this.quotes = (response.data["quote"] as List)
            .map((e) => Quote.fromJson(e))
            .toList();
        this.vectors = (response.data["vector"] as List)
            .map((e) => Vector.fromJson(e))
            .toList();
      });
      Constants.HOME_ORDER_ITEMS.addAll(this.orders);
      Constants.HOME_QUOTE_ITEMS.addAll(this.quotes);
      Constants.HOME_VECTOR_ITEMS.addAll(this.vectors);
      Constants.HOME_LOADED = true;
    } else {}
  }

  @override
  void initState() {
    if (this.mounted) {
      super.initState();
      _loadData();
    }
  }

  @override
  void setState(fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    // if (!Constants.authCheck) {
    //   Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
    // }
    return Column(
      children: [
        Stack(
          children: [
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Constants.THEME_BLUE, Constants.THEME_RED],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
              ),
              height: 230 + MediaQuery.of(context).padding.top,
              child: Column(
                children: [
                  Container(
                    width: double.infinity,
                    margin: EdgeInsets.only(
                      top: 40 + MediaQuery.of(context).padding.top,
                    ),
                    child: Text(
                      "Welcome to",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: Colors.white),
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    child: Text(
                      "USA Digitizers",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 40,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(
                top: 180 + MediaQuery.of(context).padding.top,
              ),
              child: Padding(
                padding: const EdgeInsets.only(left: 10, right: 10),
                child: Row(
                  children: [
                    Expanded(
                      child: Card(
                        color: Colors.white,
                        child: Padding(
                          padding: EdgeInsets.only(
                            top: 20,
                            bottom: 20,
                            left: 10,
                            right: 10,
                          ),
                          child: Column(
                            children: [
                              Text(
                                orders.length.toString(),
                                style: TextStyle(
                                  color: Constants.THEME_BLUE,
                                  fontSize: 25,
                                ),
                              ),
                              Text(
                                'Active Orders',
                                style: TextStyle(color: Constants.THEME_RED),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Card(
                        color: Colors.white,
                        child: Padding(
                          padding: EdgeInsets.only(
                            top: 20,
                            bottom: 20,
                            left: 10,
                            right: 10,
                          ),
                          child: Column(
                            children: [
                              Text(
                                quotes.length.toString(),
                                style: TextStyle(
                                  color: Constants.THEME_BLUE,
                                  fontSize: 25,
                                ),
                              ),
                              Text(
                                'Active Quotes',
                                style: TextStyle(color: Constants.THEME_RED),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Card(
                        color: Colors.white,
                        child: Padding(
                          padding: EdgeInsets.only(
                            top: 20,
                            bottom: 20,
                            left: 10,
                            right: 10,
                          ),
                          child: Column(
                            children: [
                              Text(
                                vectors.length.toString(),
                                style: TextStyle(
                                  color: Constants.THEME_BLUE,
                                  fontSize: 25,
                                ),
                              ),
                              Text(
                                'Active Vectors',
                                style: TextStyle(color: Constants.THEME_RED),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        Expanded(
          child: ListView(
            shrinkWrap: true,
            children: [
              HeadingText("Active Orders"),
              SizedBox(
                height: 200,
                child: (Constants.HOME_LOADED && this.orders.length == 0)
                    ? Card(
                        child: Padding(
                          padding: EdgeInsets.all(40),
                          child: Text("No active orders found"),
                        ),
                      )
                    : ListView.builder(
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemCount: this.orders.length,
                        itemBuilder: (context, index) {
                          return HomeCard(
                            number: orders[index].orderNo,
                            name: orders[index].orderName,
                            date: orders[index].createdAt,
                            type: "order",
                            item: orders[index],
                          );
                        }),
              ),
              HeadingText("Active Quotes"),
              SizedBox(
                height: 200,
                child: (Constants.HOME_LOADED && this.quotes.length == 0)
                    ? Card(
                        child: Padding(
                          padding: EdgeInsets.all(40),
                          child: Text("No active quotes found"),
                        ),
                      )
                    : ListView.builder(
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemCount: this.quotes.length,
                        itemBuilder: (context, index) {
                          return HomeCard(
                            number: quotes[index].quoteNo,
                            name: quotes[index].quoteName,
                            date: quotes[index].createdAt,
                            type: "quote",
                            item: quotes[index],
                          );
                        },
                      ),
              ),
              HeadingText("Active Vectors"),
              SizedBox(
                height: 200,
                child: (Constants.HOME_LOADED && this.vectors.length == 0)
                    ? Card(
                        child: Padding(
                          padding: EdgeInsets.all(40),
                          child: Text("No active vector orders found"),
                        ),
                      )
                    : ListView.builder(
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemCount: this.vectors.length,
                        itemBuilder: (context, index) {
                          return HomeCard(
                            number: vectors[index].vectorNo,
                            name: vectors[index].vectorName,
                            date: vectors[index].createdAt,
                            type: "vector",
                            item: vectors[index],
                          );
                        },
                      ),
              ),
            ],
          ),
        )
      ],
    );
  }
}

class HomeCard extends StatelessWidget {
  const HomeCard(
      {Key? key,
      required this.number,
      required this.name,
      required this.date,
      required this.item,
      required this.type})
      : super(key: key);

  final String number;
  final String name;
  final String date;
  final String type;
  final dynamic item;
  getDetails(type, BuildContext context) {
    if (type == "order") {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => OrderDetail(
            order: item,
          ),
        ),
      );
    }
    if (type == "quote") {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => QuoteDetail(
            quote: item,
          ),
        ),
      );
    }
    if (type == "vector") {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => VectorDetail(
            vector: item,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 20, bottom: 20),
      width: 250,
      child: InkWell(
        onTap: () {
          this.getDetails(type, context);
        },
        child: Card(
          elevation: 5,
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: double.infinity,
                  child: Text(
                    number,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Constants.THEME_BLUE,
                      fontSize: 16,
                    ),
                  ),
                ),
                Container(
                  width: double.infinity,
                  child: Text(
                    name,
                    overflow: TextOverflow.ellipsis,
                    maxLines: 2,
                    style: TextStyle(
                      color: Constants.THEME_RED,
                      fontSize: 20,
                    ),
                  ),
                ),
                Expanded(
                  child: Align(
                    alignment: FractionalOffset.bottomLeft,
                    child: Text(
                      DateFormat('yMd').format(
                        DateTime.parse(date),
                      ),
                      style: TextStyle(color: Colors.black54),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HeadingTextBig extends StatelessWidget {
  final text;
  const HeadingTextBig(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      child: Text(
        this.text,
        textAlign: TextAlign.left,
        style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 40,
          color: Constants.THEME_BLUE,
        ),
      ),
    );
  }
}

class HeadingText extends StatelessWidget {
  final String text;
  const HeadingText(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(
        left: 20,
        top: 20,
      ),
      child: Text(
        this.text,
        textAlign: TextAlign.left,
        style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 20,
          color: Constants.THEME_BLUE,
        ),
      ),
    );
  }
}
