import 'package:flutter/material.dart';
import 'package:usadigitizers/app/helpers/constants.dart';

class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback action;
  final bool hasBorder;
  CustomButton(
      {required this.text, required this.action, this.hasBorder = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60,
      margin: EdgeInsets.only(left: 30, right: 30, bottom: 10),
      child: SizedBox.expand(
        child: ElevatedButton(
          onPressed: action,
          style: ElevatedButton.styleFrom(
            backgroundColor: this.hasBorder ? Colors.transparent : THEME_BLUE,
          ),
          child: Text(
            this.text,
            style: TextStyle(
              color: this.hasBorder ? THEME_BLUE : Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}

class EditButton extends StatelessWidget {
  final String text;
  final VoidCallback action;
  final bool hasBorder;
  EditButton(
      {required this.text, required this.action, this.hasBorder = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      margin: EdgeInsets.only(left: 50, right: 50, bottom: 10),
      child: SizedBox.expand(
        child: ElevatedButton(
          onPressed: this.action,
          style: ElevatedButton.styleFrom(
            backgroundColor: this.hasBorder ? Colors.transparent : THEME_BLUE,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30.0),
              side: BorderSide(color: THEME_BLUE, width: 3),
            ),
          ),
          child: Text(
            this.text,
            style: TextStyle(
              color: this.hasBorder ? THEME_BLUE : Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}
