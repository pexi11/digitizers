import 'package:flutter/material.dart';

class CustomDropdown extends StatelessWidget {
  final dynamic value;
  final dynamic onUpdate;
  final dynamic items;
  final dynamic placeholder;
  final dynamic validator;
  CustomDropdown({
    this.value,
    this.onUpdate,
    this.items,
    this.placeholder,
    this.validator,
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 30, right: 30, bottom: 10),
      child: DropdownButtonFormField(
        isExpanded: true,
        items: this.items,
        onChanged: this.onUpdate,
        value: this.value,
        hint: Text(this.placeholder),
        validator: this.validator,
      ),
    );
  }
}
