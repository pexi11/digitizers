import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CustomTextField extends StatelessWidget {
  final String placeholder;
  final TextEditingController controller;
  final int maxLines;
  final FormFieldValidator<String>? validator;
  final bool isNumber;
  final List<TextInputFormatter> formatter;
  final bool enabled;
  CustomTextField(
      {required this.placeholder,
      required this.controller,
      required this.maxLines,
      this.validator,
      this.formatter = const [],
      this.enabled = true,
      this.isNumber = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 30, right: 30, bottom: 10),
      child: TextFormField(
        maxLines: this.maxLines,
        keyboardType: this.isNumber
            ? TextInputType.numberWithOptions(decimal: true)
            : TextInputType.text,
        controller: this.controller,
        validator: validator,
        inputFormatters: this.formatter,
        decoration: InputDecoration(
            fillColor: Colors.transparent,
            filled: true,
            contentPadding: EdgeInsets.all(0),
            labelText: this.placeholder,
            enabled: this.enabled),
      ),
    );
  }
}
